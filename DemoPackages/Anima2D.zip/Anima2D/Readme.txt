For documentation and tutorial videos go to anima2d.com, or check out the user guide in the same folder as this file.

Enjoy the Anima2D experience!!